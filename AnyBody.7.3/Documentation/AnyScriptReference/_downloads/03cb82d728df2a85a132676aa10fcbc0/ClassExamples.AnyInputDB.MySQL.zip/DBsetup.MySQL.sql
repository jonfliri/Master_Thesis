﻿/*                                                                        */
/*              AnyBodyDBTest.SQL - Creates the AnyBodyDBTest database                  */ 
/*                                                                        */
/*
** Copyright AnyBody Technology
** All Rights Reserved.
*/

create database if not exists AnyBodyDBTest;

/*create database AnyBodyDBTest;*/

use AnyBodyDBTest;

DROP TABLE IF EXISTS `anybodydbtest`.`demoarm2dmus3e`;
CREATE TABLE  `anybodydbtest`.`demoarm2dmus3e` (
  `UserID` int(10) unsigned NOT NULL,
  `MuscleName` varchar(45) NOT NULL,
  `PCSA` double NOT NULL,
  `Lfbar` double NOT NULL,
  `Gammabar` double NOT NULL,
  `Epsilonbar` double NOT NULL,
  `Fcfast` double NOT NULL,
  `K1` double NOT NULL,
  `K2` double NOT NULL,
  `Lt0` double NOT NULL,
  `Jt` double NOT NULL,
  `PEFactor` double NOT NULL,
  `Jpe` double NOT NULL,
  PRIMARY KEY  (`UserID`,`MuscleName`)
) ;

DROP TABLE IF EXISTS `anybodydbtest`.`users`;

CREATE TABLE  `anybodydbtest`.`users` (
  `UserID` int(10) unsigned NOT NULL,
  `UserName` varchar(45) NOT NULL,
  PRIMARY KEY  (`UserID`)
) ;

DROP TABLE IF EXISTS `AnyInputDB`;
CREATE TABLE  AnyInputDB(

     AnyFloatTest double NOT NULL,

     AnyIntTest int(11) NOT NULL,

     AnyStringTest varchar(45) NOT NULL

 );

insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0, 'BicepsLong', 1.94, 0.136, 2, 0.05, 0.4, 8, 2, 0.16, 3, 1.5, 3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0, 'BicepsShort', 2.1, 0.15,	2,	0.053,	0.4,	8,	2,	0.15, 3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'Brachialis',	9,	0.09,	2,	0.053,	0.4,	8,	2,	0.03,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'Brachioradialis',	1.5,	0.16,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'DeltoideusA',	8.8,	0.05,	5,	0.05,	0.4,	8,	2,	0.1, 3, 1.5, 3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'DeltoideusB',	8.8,	0.05,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'TricepsLong',	6.7,	0.102,	2,	0.053,	0.4,	8,	2,	0.2,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(0,	'TricepsShort',	8,	0.09,	2,	0.05,	0.4,	8,	2,	0.15,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1, 'BicepsLong', 1.36, 0.136, 2, 0.05, 0.4, 8, 2, 0.16, 3, 1.5, 3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1, 'BicepsShort', 1.47, 0.15,	2,	0.053,	0.4,	8,	2,	0.15, 3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'Brachialis',	6.3,	0.09,	2,	0.053,	0.4,	8,	2,	0.03,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'Brachioradialis',	1.05,	0.16,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'DeltoideusA',	5.7,	0.05,	5,	0.05,	0.4,	8,	2,	0.1, 3, 1.5, 3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'DeltoideusB',	5.7,	0.05,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'TricepsLong',	4,	0.102,	2,	0.053,	0.4,	8,	2,	0.2,	3,	1.5,	3);
insert into demoarm2dmus3e (UserID, MuscleName, PCSA, Lfbar, Gammabar, Epsilonbar, Fcfast, K1, K2, Lt0, Jt, PEFactor, Jpe)
	values(1,	'TricepsShort',	5.6,	0.09,	2,	0.05,	0.4,	8,	2,	0.15,	3,	1.5,	3);
		
insert into users (UserID, UserName)
   values(0, 'Ken');
insert into users (UserID, UserName)
   values(1, 'Barbie');

insert into AnyInputDB (AnyFloatTest, AnyIntTest,AnyStringTest)
   values(23.2, 4, 'head');
insert into AnyInputDB (AnyFloatTest, AnyIntTest,AnyStringTest)
   values(25.6, 7, 'neck');
insert into AnyInputDB (AnyFloatTest, AnyIntTest,AnyStringTest)
   values(26.2, 9, 'hip');

/*
load data local infile 'demoarm2dmus3e.csv" into table demoarm2dmus3e field terminated by ',' lines terminated by '\n';
load data local infile 'users.csv" into table users field terminated by ',' lines terminated by '\n';
load data local infile 'AnuInputDB.csv" into table AnuInputDB field terminated by ',' lines terminated by '\n';
*/