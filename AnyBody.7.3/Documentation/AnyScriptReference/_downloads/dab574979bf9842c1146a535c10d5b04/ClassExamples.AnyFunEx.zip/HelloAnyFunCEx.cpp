// HelloAnyFunCEx.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "IAnyBodyDefs.h"

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


extern "C"
{
  __declspec(dllexport) bool TestCEx(IAnyBody::IAData* pIADataReturn, const IAnyBody::IAData** pIAData);
}

__declspec(dllexport) bool TestCEx(IAnyBody::IAData* pIADataReturn, const IAnyBody::IAData** pIADataArray)
{
  double d0, d1, d2;
  IAnyBody::IAError res = pIADataArray[0]->_Get(d0, 0);
  if (res != IAnyBody::NoError) return false;
  res = pIADataArray[0]->_Get(d1, 1);
  if (res != IAnyBody::NoError) return false;
  res = pIADataArray[0]->_Get(d2, 2);
  if (res != IAnyBody::NoError) return false;

  res = pIADataReturn->_Set(d0 * 100.0, 0);
  if (res != IAnyBody::NoError) return false;
  res = pIADataReturn->_Set(d1 * 200.0, 1);
  if (res != IAnyBody::NoError) return false;
  res = pIADataReturn->_Set(d2 * 100.0, 2);
  if (res != IAnyBody::NoError) return false;

  return true;
}
