/*                                                                        */
/*              AnyBodyDBTest.SQL - Creates the AnyBodyDBTest database                  */ 
/*                                                                        */
/*
** Copyright AnyBody Technology
** All Rights Reserved.
*/

SET NOCOUNT ON
GO

set nocount    on
set dateformat mdy

USE master

declare @dttm varchar(55)
select  @dttm=convert(varchar,getdate(),113)
raiserror('Beginning AnyBodyDBTest.SQL at %s ....',1,1,@dttm) with nowait
--GO
--
--if exists (select * from sys.databases where name='AnyBodyDBTest')
--begin
--  raiserror('Dropping existing AnyBodyDBTest database ....',0,1)
--  DROP database AnyBodyDBTest
--end
GO

CHECKPOINT
go

raiserror('Creating AnyBodyDBTest database....',0,1)
go
/*
   Use default size with autogrow
*/
if not exists (select * from sys.databases where name='AnyBodyDBTest')
begin
	CREATE DATABASE AnyBodyDBTest
end
GO

CHECKPOINT

GO

USE AnyBodyDBTest

GO

if db_name() <> 'AnyBodyDBTest'
   raiserror('Error in AnyBodyDBTest.SQL, ''USE AnyBodyDBTest'' failed!  Killing the SPID now.'
            ,22,127) with log

GO

execute sp_dboption 'AnyBodyDBTest' ,'trunc. log on chkpt.' ,'true'
GO


raiserror('Now at the create table DemoArm2DMus3E2 section ....',0,1)

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON

GO
if exists (select * from sys.tables where name='DemoArm2DMus3E')
begin
	drop table DemoArm2DMus3E
end

GO
CREATE TABLE [dbo].[DemoArm2DMus3E](
	[UserID] [int] NOT NULL,
	[MuscleName] [varchar](50) NOT NULL,
	[PCSA] [float] NULL,
	[Lfbar] [float] NULL,
	[Gammabar] [float] NULL,
	[Epsilonbar] [float] NULL,
	[Fcfast] [float] NULL,
	[K1] [float] NULL,
	[K2] [float] NULL,
	[Lt0] [float] NULL,
	[Jt] [float] NULL,
	[PEFactor] [float] NULL,
	[Jpe] [float] NULL,
 CONSTRAINT [PK_DemoArm2DMus3E] PRIMARY KEY CLUSTERED 
(
	[UserID] ASC,
	[MuscleName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


raiserror('Now at the create table Users section ....',0,1)

GO
if exists (select * from sys.tables where name='Users')
begin
	drop table Users
end

GO
CREATE TABLE [dbo].[Users](
	[UserID] [int] NOT NULL,
	[UserName] [varchar](50) NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


raiserror('Now at the create table AnyInputDB section ....',0,1)

GO
if exists (select * from sys.tables where name='AnyInputDB')
begin
	drop table AnyInputDB
end
GO
CREATE TABLE [dbo].[AnyInputDB](
	[AnyFloatTest] [float] NULL,
	[AnyIntTest] [int] NULL,
	[AnyStringTest] [varchar](50) NULL
) ON [PRIMARY]

GO

raiserror('Now at the inserts to DemoArm2DMus3E ....',0,1)

GO

--BULK 
--INSERT [dbo].[DemoArm2DMus3E]
--        FROM 'DemoArm2DMus3E.csv'
--            WITH
--    (
--                FIELDTERMINATOR = ',',
--                ROWTERMINATOR = '\n'
--    )
--GO
insert DemoArm2DMus3E
   values(0, 'BicepsLong', 1.94, 0.136, 2, 0.05, 0.4, 8, 2, 0.16, 3, 1.5, 3)
insert DemoArm2DMus3E
   values(0, 'BicepsShort', 2.1, 0.15,	2,	0.053,	0.4,	8,	2,	0.15, 3,	1.5,	3)
insert DemoArm2DMus3E
   values(0,	'Brachialis',	9,	0.09,	2,	0.053,	0.4,	8,	2,	0.03,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(0,	'Brachioradialis',	1.5,	0.16,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(0,	'DeltoideusA',	8.8,	0.05,	5,	0.05,	0.4,	8,	2,	0.1, 3, 1.5, 3)
insert DemoArm2DMus3E
   values(0,	'DeltoideusB',	8.8,	0.05,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(0,	'TricepsLong',	6.7,	0.102,	2,	0.053,	0.4,	8,	2,	0.2,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(0,	'TricepsShort',	8,	0.09,	2,	0.05,	0.4,	8,	2,	0.15,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(1, 'BicepsLong', 1.36, 0.136, 2, 0.05, 0.4, 8, 2, 0.16, 3, 1.5, 3)
insert DemoArm2DMus3E
   values(1, 'BicepsShort', 1.47, 0.15,	2,	0.053,	0.4,	8,	2,	0.15, 3,	1.5,	3)
insert DemoArm2DMus3E
   values(1,	'Brachialis',	6.3,	0.09,	2,	0.053,	0.4,	8,	2,	0.03,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(1,	'Brachioradialis',	1.05,	0.16,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(1,	'DeltoideusA',	5.7,	0.05,	5,	0.05,	0.4,	8,	2,	0.1, 3, 1.5, 3)
insert DemoArm2DMus3E
   values(1,	'DeltoideusB',	5.7,	0.05,	5,	0.05,	0.4,	8,	2,	0.1,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(1,	'TricepsLong',	4,	0.102,	2,	0.053,	0.4,	8,	2,	0.2,	3,	1.5,	3)
insert DemoArm2DMus3E
   values(1,	'TricepsShort',	5.6,	0.09,	2,	0.05,	0.4,	8,	2,	0.15,	3,	1.5,	3)

GO

raiserror('Now at the inserts to Users ....',0,1)

GO

--BULK 
--INSERT [dbo].[Users]
--        FROM 'Users.csv'
--            WITH
--    (
--                FIELDTERMINATOR = ',',
--                ROWTERMINATOR = '\n'
--    )
--GO

insert Users
	values(0, 'Ken')
insert Users
	values(1, 'Barbie')

GO

raiserror('Now at the inserts to AnyInputDB ....',0,1)

GO

--BULK 
--INSERT [dbo].[AnyInputDB]
--        FROM 'AnyInputDB.csv'
--            WITH
--    (
--                FIELDTERMINATOR = ',',
--                ROWTERMINATOR = '\n'
--    )
--GO
insert AnyInputDB
   values(23.2, 4, 'head')
insert AnyInputDB
   values(25.6, 7, 'neck')
insert AnyInputDB
   values(26.2, 9, 'hip')
   
declare @dttm varchar(55)
select  @dttm=convert(varchar,getdate(),113)
raiserror('Ending InstPubs.SQL at %s ....',1,1,@dttm) with nowait

GO
SET ANSI_PADDING OFF
--
